package come.role.eao;
 
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import com.role.utils.ReleaseConnection;
import com.role.utils.Settings;

import entity.Role;

@Stateless
public class RoleEao {
	public List<Role> getRole(int intCompanyID, String userAccount) {
		List<Role> listRole = new ArrayList<Role>();
		Connection connection = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_RoleGet(?,?)}");
			cs.setInt(1, intCompanyID);
			cs.setString(2, userAccount);
			rs = cs.executeQuery();
			while (rs.next()) {
				Role role = new Role();
				role.setIntRoleID(rs.getInt("IntRoleID"));
				role.setRoleUID(rs.getString("RoleUID"));
				role.setIntCompanyID(rs.getInt("IntCompanyID"));
				role.setRoleCode(rs.getString("RoleCode"));
				role.setRoleName(rs.getString("RoleName"));
				role.setFgRoleStatus(rs.getInt("FgRoleStatus"));
				role.setFgDeleted(rs.getInt("FgDeleted"));
				role.setFgFlowStatus(rs.getInt("FgFlowStatus"));
				role.setSubmitDescription(rs.getString("SubmitDescription"));
				role.setRejectDescription(rs.getString("RejectDescription"));
				role.setTimeLastUpdate(rs.getTimestamp("TimeLastUpdate"));
				role.setUserLastUpdate(rs.getString("UserLastUpdate"));
				role.setTimeBeginJob(rs.getTimestamp("TimeBeginJob"));
				role.setUserBeginJob(rs.getString("UserBeginJob"));
				role.setTimeSubmit(rs.getTimestamp("TimeSubmit"));
				role.setUserSubmit(rs.getString("UserSubmit"));
				role.setTimeLastApprove(rs.getTimestamp("TimeLastApprove"));
				role.setUserLastApprove(rs.getString("UserLastApprove"));

				listRole.add(role);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs, rs);
		}
		return listRole;
	}

	public List<Role> getRoleMenu(int intCompanyID, int roleID, String User) {
		List<Role> listRoleMenu = new ArrayList<Role>();
		Connection connection = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_MapRoleMenuGet(?,?,?)}");
			cs.setInt(1, intCompanyID);
			cs.setInt(2, roleID);
			cs.setString(3, User);
			rs = cs.executeQuery();
			while (rs.next()) {
				Role menu = new Role();
				menu.setIntRoleID(rs.getInt("IntRoleID"));
				menu.setIntCompanyID(rs.getInt("IntCompanyID"));
				menu.setIntMenuID(rs.getInt("IntMenuID"));
				menu.setMenuName(rs.getString("MenuName"));
				menu.setFgMenuType(rs.getString("FgMenuType"));
				menu.setIntParentMenuID(rs.getInt("IntParentMenuID"));
				menu.setFgAllow(rs.getInt("FgAllow"));
				menu.setFgFlowStatusDetail(rs.getInt("FgFlowStatusDetail"));
				menu.setFgFlowStatusText(rs.getString("FgFlowStatusDetailText"));
				menu.setTimeBeginJob(rs.getTimestamp("TimeBeginJob"));
				menu.setUserBeginJob(rs.getString("UserBeginJob"));
				menu.setTimeSubmit(rs.getTimestamp("TimeSubmit"));
				menu.setUserSubmit(rs.getString("UserSubmit"));
				menu.setTimeLastApprove(rs.getTimestamp("TimeLastApprove"));
				menu.setUserLastApprove(rs.getString("UserLastApprove"));

				listRoleMenu.add(menu);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs, rs);
		}
		return listRoleMenu;
	}

	public Role roleAdd(Role rl, int CompID, String MenuXML, String User) {
		Role role = new Role();
		Connection connection = null;
		CallableStatement cs = null;
		System.out.println("eao kode role " + rl.getRoleCode());
		System.out.println("int role eao " + rl.getIntRoleID());
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_RoleCreate(?,?,?,?,?,?,?,?,?)}");
			cs.setInt(1, CompID);
			cs.setString(2, rl.getRoleCode());
			cs.setString(3, rl.getRoleName());
			cs.setString(4, MenuXML);
			System.out.println("XML eao " + MenuXML);
			cs.setString(5, User);
			cs.registerOutParameter(6, java.sql.Types.INTEGER);
			cs.registerOutParameter(7, java.sql.Types.VARCHAR);
			cs.registerOutParameter(8, java.sql.Types.INTEGER);
			cs.registerOutParameter(9, java.sql.Types.INTEGER);
			cs.executeUpdate();

			role.setIntRoleID(cs.getInt("OutIntRoleID"));
			role.setOutRoleUID(cs.getString("OutRoleUID"));
			role.setResultSuccess(cs.getInt("ResultSuccess"));
			role.setErrorMessage(cs.getInt("ErrorMessage"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs);
		}
		return role;
	}

	public Role roleDelete(Role del) {
		Role role = new Role();
		Connection connection = null;
		CallableStatement cs = null;
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_RoleDelete(?,?,?,?,?,?,?)}");
			cs.setInt(1, del.getIntCompanyID());
			cs.setInt(2, del.getIntRoleID());
			cs.setString(3, del.getRoleUID());
			cs.setString(4, del.getDeleteReason());
			cs.setString(5, "system");
			cs.registerOutParameter(6, java.sql.Types.INTEGER);
			cs.registerOutParameter(7, java.sql.Types.INTEGER);
			cs.executeUpdate();
			role.setResultSuccess(cs.getInt("ResultSuccess"));
			role.setErrorMessage(cs.getInt("ErrorMessage"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs);
		}
		return role;
	}

	public Role aktifTidakAktif(Role active) {
		Role role = new Role();
		Connection connection = null;
		CallableStatement cs = null;
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_RoleStatusSetActive(?,?,?,?,?)}");
			cs.setInt(1, active.getIntCompanyID());
			cs.setInt(2, active.getIntRoleID());
			cs.setString(3, "system");
			cs.registerOutParameter(4, java.sql.Types.INTEGER);
			cs.registerOutParameter(5, java.sql.Types.INTEGER);
			cs.executeUpdate();
			role.setResultSuccess(cs.getInt("ResultSuccess"));
			role.setErrorMessage(cs.getInt("ErrorMessage"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs);
		}
		return role;
	}

	public Role roleEdit(Role edit, Role old, String menuXML, String User) {
		Role role = new Role();
		Connection connection = null;
		CallableStatement cs = null;
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_RoleEdit(?,?,?,?,?,?,?,?,?,?,?)}");
			cs.setInt(1, old.getIntCompanyID());
			cs.setInt(2, old.getIntRoleID());
			cs.setString(3, old.getRoleUID());
			cs.setString(4, edit.getRoleCode());
			cs.setString(5, edit.getRoleName());
			cs.setInt(6, edit.getFgRoleStatus());
			cs.setString(7, edit.getSubmitDescription());
			cs.setString(8, menuXML);
			cs.setString(9, User);
			cs.registerOutParameter("ResultSuccess", java.sql.Types.INTEGER);
			cs.registerOutParameter("ErrorMessage", java.sql.Types.INTEGER);
			cs.executeUpdate(); // buat jalanin perintah sql
			role.setResultSuccess(cs.getInt("ResultSuccess")); // menampung error message
			role.setErrorMessage(cs.getInt("ErrorMessage"));
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs);
		}
		return role;
	}

}
