package come.role.eao;
 
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import com.role.utils.ReleaseConnection;
import com.role.utils.Settings;

import entity.ErrorCode;

@Stateless
public class ErrorCodeEao {
	
	public List<ErrorCode> getErrorCode() {
		List<ErrorCode> listErrorCode = new ArrayList<ErrorCode>();
		Connection connection = null;
		CallableStatement cs = null;
		ResultSet rs = null;
		try {
			connection = Settings.getConnection();
			cs = connection.prepareCall("{call sp_sys_ErrorCodeGet}");
			rs = cs.executeQuery();
			while(rs.next()) {
				ErrorCode ec = new ErrorCode();
				ec.setErrorCode(rs.getInt("ErrorCode"));
				ec.setErrorMessageID(rs.getString("ErrorMessage_ID"));
				listErrorCode.add(ec);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ReleaseConnection.close(connection, cs, rs);
		}
		return listErrorCode;
	}
}