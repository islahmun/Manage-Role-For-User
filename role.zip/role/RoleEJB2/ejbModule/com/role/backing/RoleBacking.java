package com.role.backing;

import java.io.Serializable;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.ToggleSelectEvent;
import org.primefaces.event.UnselectEvent;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.role.rules.RoleRules;

import entity.Role;

@Named
@SessionScoped

public class RoleBacking extends BasicBacking implements Serializable {
	private static final long serialVersionUID = 7440013434066133023L;
	@EJB
	private RoleRules roleRules;

	private List<Role> listRole = new ArrayList<Role>();
	// private List<Role> listRoleMenu = new ArrayList<Role>();
	private List<Role> listSelected = new ArrayList<Role>();
	private List<Role> listMenu;
	private List<Role> listSelection;

	private Role rule = new Role();
	private Role edit = new Role();
	private Role old = new Role();

	public List<Role> getListSelection() {
		return listSelection;
	}   

	public void setListSelection(List<Role> listSelection) {
		this.listSelection = listSelection;
	}

	public List<Role> getListMenu() {
		return listMenu;
	}

	public void setListMenu(List<Role> listMenu) {
		this.listMenu = listMenu;
	}

	public Role getEdit() {
		return edit;
	}

	public void setEdit(Role edit) {
		this.edit = edit;
	}

	public Role getOld() {
		return old;
	}

	public void setOld(Role old) {
		this.old = old;
	}

	public List<Role> getListSelected() {
		return listSelected;
	}

	public void setListSelected(List<Role> listSelected) {
		this.listSelected = listSelected;
	}

	public RoleRules getRoleRules() {
		return roleRules;
	}

	public void setRoleRules(RoleRules roleRules) {
		this.roleRules = roleRules;
	}

	public Role getRule() {
		return rule;
	}

	public void setRule(Role rule) {
		this.rule = rule;
	}

	public List<Role> getListRole() {
		return listRole;
	}

	public void setListRole(List<Role> listRole) {
		this.listRole = listRole;
	}

	public void flashMessage() {
		FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);
		FacesContext.getCurrentInstance().getExternalContext().getFlash().setRedirect(true);
	}

	public void messageHandler(String errorMessage) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(errorMessage));
	}

	public void loadListRole() {
		listRole = roleRules.getRole(-1, "system");
		System.out.println("list " + listRole.size());
	}

	public String redirecToAdd() {
		listMenu = new ArrayList<Role>();
		return "roleadd.xhtml?faces-redirect=true";
	}

	public void loadListRoleMenu() {
		listMenu = roleRules.getRoleMenu(-1, -1, "system");
		System.out.println("list menu " + listMenu.size());
	}

	public String cancel() {
		//listMenu = new ArrayList<Role>(); //clear 
		listSelected = new ArrayList<Role>(); //clear list yang dipilih saat klik cancel
		rule = new Role(); // clear kode dan nama role saat cancel
		// listSelection = new ArrayList<Role>();
		return "menurole.xhtml?faces-redirect=true";
	}

	public String deleteRole(Role dell) {
		Role roleOut = roleRules.deleteRole(dell);
		System.out.println("id delete " + dell.getIntRoleID());
		if (roleOut.getResultSuccess() == 1 || roleOut.getResultSuccess() == 2) {
			messageHandler("Role berhasil di delete ",FacesMessage.SEVERITY_INFO);
			flashMessage();
			// rule = new Role();
			return "menurole.xhtml?faces-redirect=true";
		} else {
			messageHandler("Gagal delete role ",FacesMessage.SEVERITY_ERROR);
			return null;
		}
	}

	public String aktifTidakAktif(Role active) {
		Role roleOut = roleRules.aktifTidakAktif(active);
		if (roleOut.getResultSuccess() == 1 || roleOut.getResultSuccess() == 2) {
			messageHandler("Role berhasil di aktifkan ",FacesMessage.SEVERITY_INFO);
			flashMessage();
			/* rule = new Role(); */
		} else {
			messageHandler("Role gagal di aktifkan ", FacesMessage.SEVERITY_ERROR);
			loadListRole();
			return "menurole.xhtml?faces-redirect=true";
		}
		return null;
	}

	public String addRole() {
		if (rule.getRoleCode() != null && rule.getRoleCode().trim().isEmpty()) {
			//messageHandler(String.valueOf(roleOut.getErrorMessage()));
			messageHandler("Kode tidak boleh kosong", FacesMessage.SEVERITY_ERROR);
			
			return null;
		} else if (rule.getRoleName() != null && rule.getRoleName().trim().isEmpty() ) {
			messageHandler("Nama tidak boleh kosong", FacesMessage.SEVERITY_ERROR);
			return null;
		} else {	
			Role roleOut = roleRules.addRole(rule, -1, createXML(), "system");
			System.out.println("nama role input " + rule.getRoleName());
			if (roleOut.getResultSuccess() == 1 || roleOut.getResultSuccess() == 2) {
				messageHandler("Role berhasil ditambahkan ", FacesMessage.SEVERITY_INFO);
				flashMessage();
				rule = new Role();
				listSelected = new ArrayList<Role>();
				System.out.println("Xml baking " + createXML());
				return "menurole.xhtml?faces-redirect=true";
			} else {
				messageHandler("Kode atau Nama role sudah ada" ,FacesMessage.SEVERITY_WARN);
				return null;
			}
		 }
	}

	public String createXML() {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		StringWriter writter = new StringWriter();
		DocumentBuilder docBuilder;
		try {
			// root elements
			docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("Menus");
			doc.appendChild(rootElement);

			for (Role r : listMenu) {
				// staff elements
				Element menu = doc.createElement("Menu");
				rootElement.appendChild(menu);

				Element intMenuID = doc.createElement("IntMenuID");
				intMenuID.appendChild(doc.createTextNode(String.valueOf(r.getIntMenuID())));
				menu.appendChild(intMenuID);

				Element fgAllow = doc.createElement("FgAllow");
				fgAllow.appendChild(doc.createTextNode(String.valueOf(r.getFgAllow())));
				menu.appendChild(fgAllow);
			}
			// write the content into xml file
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(new DOMSource(doc), new StreamResult(writter));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return writter.toString();
	}
	
	public void allSelect(ToggleSelectEvent event) {
		//Role sel = (Role) event.getObject();
		if (event.isSelected() == false) {
			for (Role loop : listMenu) {
				loop.setFgAllow(0);
				System.out.println("all unselect fgallow " + loop.getFgAllow());
			}
		}else {
			for (Role loop : listMenu) { //listselected
				loop.setFgAllow(1);
				System.out.println("all select fgallow " + loop.getFgAllow());
			}
		}
	}
	
	public void onSelect(SelectEvent event) {
		Role sel = (Role) event.getObject();
		// FacesMessage message = new FacesMessage(String.valueOf(sel.getIntMenuID()));
		sel.setFgAllow(1);
		System.out.println("apa isi event  " + event);
		System.out.println("intMenuId " + sel.getIntMenuID());
		System.out.println("check fgallow check " + sel.getFgAllow());
		// sel.setIntMenuID(Integer.valueOf(message.getDetail()));
	}

	public void unSelect(UnselectEvent event) {
		Role sel = (Role) event.getObject();
		// FacesMessage message = new FacesMessage(String.valueOf(sel.getIntMenuID()));
		sel.setFgAllow(0);
		System.out.println("check fgallow uncheck " + sel.getFgAllow());
		// rule.setIntMenuID(Integer.valueOf(message.getDetail()));
	}

	public void loadListRoleMenuEdit() {
		listMenu = roleRules.getRoleMenu(-1, old.getIntRoleID(), "system");
		System.out.println("edit role id " + old.getIntRoleID());
		for (Role loop : listMenu) {
			if (old.getIntRoleID() == loop.getIntRoleID()) {
				if (loop.getFgAllow() == 1) {
					System.out.println("fg allow -> " + loop.getFgAllow());
					listSelection.add(old.getIntMenuID(), loop);
				}
			}
		}
		System.out.println("list menu edit backing " + listMenu.size());
	}

	public String editRole(Role edt) {
		listSelection = new ArrayList<Role>();
		old.setIntCompanyID(edt.getIntCompanyID());
		old.setIntRoleID(edt.getIntRoleID());
		old.setRoleUID(edt.getRoleUID());

		edit.setRoleCode(edt.getRoleCode());
		edit.setRoleName(edt.getRoleName());
		edit.setFgRoleStatus(edt.getFgRoleStatus());
		edit.setSubmitDescription(edt.getSubmitDescription());
		edit.setMenuXML(edt.getMenuXML());

		return "roleedit.xhtml?faces-redirect=true";
	}

	public String updateRole() { // fungsi
		Role roleOut = roleRules.editRole(edit, old, createXML(), "system");
		if (roleOut.getResultSuccess() == 1 || roleOut.getResultSuccess() == 2) {
			messageHandler("Role berhasil di edit ", FacesMessage.SEVERITY_INFO);
			flashMessage();
			// System.out.println("sukses");
			// loadListRole();
			// edit = new Role();
			listSelection = new ArrayList<Role>();
			return "menurole.xhtml?faces-redirect=true";
		} else {
			messageHandler("Kode atau Nama role sudah ada ", FacesMessage.SEVERITY_ERROR);
			//messageHandler(String.valueOf(roleOut.getErrorMessage()));
			return null;
		}
	}
	
//	public static boolean isNullOrEmpty(String string) {
//    	if(string != null && !string.trim().isEmpty())
//            return false;
//        return true;
//    }

}
