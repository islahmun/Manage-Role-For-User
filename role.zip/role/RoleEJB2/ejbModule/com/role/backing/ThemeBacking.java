package com.role.backing;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class ThemeBacking implements Serializable {
	
	private static final long serialVersionUID = 7003979475856920051L;
	
	private Map<String,String> themeColors;
    
    private String theme = "cyan-amber";
    private String topBarColor = "layout-topbar-cyan";
    private String menuMode = "layout-static";
    private String menuColor = "layout-menu-light";
    private String logo = "images/logo-olympia.png";
    private String logoSmall = "images/adrena-logo-green.png";
    private String logoWhite = "images/AdrenaSmall.png";
    String menuLayout = "static";
    
    private boolean orientationRTL;
        
    @PostConstruct
    public void init() {
        themeColors = new HashMap<String,String>();
        themeColors.put("amber-teal", "#3a3e45");
    }
    
	public String getTheme() {		
		return theme;
	}
    
    public String getMenuLayout() {	
        if(this.menuLayout.equals("static"))
            return "menu-layout-static";
        else if(this.menuLayout.equals("overlay"))
            return "menu-layout-overlay";
        else if(this.menuLayout.equals("horizontal"))
            return "menu-layout-static menu-layout-horizontal";
        else
            return "menu-layout-static";
    }
    
	public String getLogoWhite() {
		return logoWhite;
	}

	public void setLogoWhite(String logoWhite) {
		this.logoWhite = logoWhite;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}
    
    public void setMenuLayout(String menuLayout) {
        this.menuLayout = menuLayout;
    }
    
    public Map getThemeColors() {
        return this.themeColors;
    }
    
    public boolean isOrientationRTL() {
        return orientationRTL;
    }

    public void setOrientationRTL(boolean orientationRTL) {
        this.orientationRTL = orientationRTL;
    }

	public String getTopBarColor() {
		return topBarColor;
	}

	public void setTopBarColor(String topBarColor) {
		this.topBarColor = topBarColor;
	}

	public String getMenuMode() {
		return menuMode;
	}

	public void setMenuMode(String menuMode) {
		this.menuMode = menuMode;
	}

	public String getMenuColor() {
		return menuColor;
	}

	public void setMenuColor(String menuColor) {
		this.menuColor = menuColor;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public void setThemeColors(Map<String, String> themeColors) {
		this.themeColors = themeColors;
	}

	public String getLogoSmall() {
		return logoSmall;
	}

	public void setLogoSmall(String logoSmall) {
		this.logoSmall = logoSmall;
	}
	
}