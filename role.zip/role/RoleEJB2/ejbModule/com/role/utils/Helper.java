package com.role.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import javax.json.Json;
import javax.json.JsonObject;

public class Helper {
	
	public static String urlExpander(String ShortenedUrl) {
		String expandedURL = null;
		try {
			URL url = new URL(ShortenedUrl);
			
			HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
			
			httpConnection.setInstanceFollowRedirects(false);
			
			expandedURL = httpConnection.getHeaderField("Location");
            httpConnection.disconnect();
            
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return expandedURL;
	}
	
	public static String formatCurrency(float Amount, String CurrencySymbol) {
		DecimalFormat decimalFormat = (DecimalFormat) DecimalFormat.getCurrencyInstance();
		
		DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
		decimalFormatSymbols.setCurrencySymbol(CurrencySymbol + " ");
		decimalFormatSymbols.setMonetaryDecimalSeparator(',');
		decimalFormatSymbols.setGroupingSeparator('.');
		try {
			decimalFormat.setDecimalFormatSymbols(decimalFormatSymbols);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return decimalFormat.format(Amount);
	}
	
	public static String formatCurrency(Double Amount, String CurrencySymbol) {
		DecimalFormat decimalFormat = (DecimalFormat) DecimalFormat.getCurrencyInstance();
		
		DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
		decimalFormatSymbols.setCurrencySymbol(CurrencySymbol + " ");
		decimalFormatSymbols.setMonetaryDecimalSeparator(',');
		decimalFormatSymbols.setGroupingSeparator('.');
		try {
			decimalFormat.setDecimalFormatSymbols(decimalFormatSymbols);
		} catch (Exception e) {
			e.printStackTrace();
		}
        return decimalFormat.format(Amount);
	}
	
	private static String readInputStream(InputStream inputStream) {
		try {
			ByteArrayOutputStream result = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int length;
			while ((length = inputStream.read(buffer)) != -1) {
			    result.write(buffer, 0, length);
			}
			return result.toString(StandardCharsets.UTF_8.name());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static String getProfilePicture(String UserProfilePict) {
		if (UserProfilePict != null) {
			try {
				URL urlDownload = new URL(UserProfilePict);
				HttpURLConnection conDownload = (HttpURLConnection) urlDownload.openConnection();
				conDownload.setUseCaches(false);
				conDownload.setDoOutput(true);
				conDownload.setDoInput(true);
				conDownload.setRequestProperty("Content-Type", "application/json");
				conDownload.setRequestMethod("GET");
				
				int httpResponseDownload = conDownload.getResponseCode();
				if (httpResponseDownload == HttpURLConnection.HTTP_OK) {
					String responseDownload = readInputStream(conDownload.getInputStream());
					JsonObject jsonDownload = Json.createReader(new StringReader(responseDownload)).readObject();
					return jsonDownload.getJsonObject("object").getString("url");
				} else {
					readInputStream(conDownload.getErrorStream());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}