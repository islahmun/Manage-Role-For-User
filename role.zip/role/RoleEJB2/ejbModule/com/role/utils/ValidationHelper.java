package com.role.utils;

public class ValidationHelper {
	
    public static boolean isNullOrEmpty(String string) {
    	if(string != null && !string.trim().isEmpty())
            return false;
        return true;
    }
    
	public static String validatePassword(String password) {
		String error = "SUCCESS";
		if(!password.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d!-~]{8,}$")){
			error = "ERROR";
		}
		return error;
	}
	
	public static String validationStringLength(String checkString, int minLength, int maxLength) {
		String message = "SUCCESS";
		if(checkString.length() < minLength || checkString.length() > maxLength) {
			message = "ERROR";
		}
		return message;
	}
	
	public static Boolean emailFormat(String email) {
		if (!email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")) {
			return false;
		}
		return true;
	} 
	public static String websiteFormat(String websiteURL) {
		String message = "SUCCESS";
		if (!websiteURL.matches("^((https?|ftp|smtp):\\/\\/)?(www.)?[a-z0-9]+\\.[a-z]+(\\/[a-zA-Z0-9-_#]+\\/?)*$")) {
			 message = "ERROR";
		}
		return message;
	} 
	
	public static String checkStringLength(String checkString, int length) {
		String message = "SUCCESS";
		if(checkString.length() < length) {
			message = "ERROR";
		}
		return message;
	}
	
	public static String alphaWithSpaceOnly(String email) {
		String message = "SUCCESS";
		if (!email.matches("^[a-zA-Z ]+$")) {
			 message = "ERROR";
		}
		return message;
	} 
	
	public static String alphaOnly(String email) {
		String message = "SUCCESS";
		if (!email.matches("^[a-zA-Z]+$")) {
			 message = "ERROR";
		}
		return message;
	} 
	
	public static String alphaNumeric(String validateThis) {
		String message = "SUCCESS";
		if (!validateThis.matches("^[a-zA-Z0-9]+$")) {
			 message = "ERROR";
		}
		return message;
	} 
	
	public static String onlyNumeric(String validateThis) {
		String message = "SUCCESS";
		if (!validateThis.matches("^[0-9]+$")) {
			 message = "ERROR";
		}
		return message;
	} 
	
	public static String getNPWPFormat(String npwp) {
		String[] arrayNPWP = new String[6];
		arrayNPWP[0] = npwp.substring(0,2);
		arrayNPWP[1] = npwp.substring(2,5);
		arrayNPWP[2] = npwp.substring(5,8);
		arrayNPWP[3] = npwp.substring(8,9);
		arrayNPWP[4] = npwp.substring(9,12);
		arrayNPWP[5] = npwp.substring(12,15);
		String npwpgabung = arrayNPWP[0] + "." +  arrayNPWP[1]+ "." + arrayNPWP[2] +"."+ 
							arrayNPWP[3]+ "-" + arrayNPWP[4] +"."+ arrayNPWP[5];
		return npwpgabung;
	}
	
	public static String removeNPWPSymbol(String npwp) {
		String removeDot = npwp.replace(".", "");
		String removeStrip = removeDot.replace("-", "");
		return removeStrip;
	}
	
	public static String removeStripSymbol(String eraseThisString) {
		return  eraseThisString.replace("-", "");
	}
	
	public static String removeSymbol(String eraseThisString, String symbol) {
		return  eraseThisString.replace(symbol, "");
	}
	
}