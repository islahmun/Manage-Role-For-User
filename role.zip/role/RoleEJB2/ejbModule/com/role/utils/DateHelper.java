package com.role.utils;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DateHelper {
	
	public static Locale LocaleIndonesia() {
		return new Locale("id", "ID");
	}
	
	public static Date getCurrentDateTime() {
		return new Date();
	}
	
	public static LocalDate getLocalDate() {
		return LocalDate.now();
	}
	
	public static boolean isBeforeDate(Date check, Date against) {
		if(against.equals(null) || against == null)
			return false;
		else {
			LocalDate localCheck = check.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LocalDate localAgainst = against.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			if(localCheck.isBefore(localAgainst))
				return true;
			else
				return false;	
		}
	}
	
	public static boolean isAfterDate(Date check, Date against) {
		LocalDate localCheck = check.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate localAgainst = against.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		if(localCheck.isAfter(localAgainst))
			return true;
		else
			return false;
	}
	
	public static String formatDateToString(Date date, String datePattern) {
		if(date != null) {
			DateFormat df = new SimpleDateFormat(datePattern);
			return df.format(date);
		} else
			return null;
	}
	
	public static Date formatStringToDate(String date, String datePattern) {
		if(date != null) {
			DateFormat df = new SimpleDateFormat(datePattern);
			Date d = new Date();
			try {
				d = df.parse(date);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return d;
		} else
			return null;
	}

	public static int extractDateMonthAsInt(Date date) {
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getMonthValue();
	}
	
	public static String extractDateMonthAsString(Date date) {
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
	}
	
	public static int extractDateYearAsInt(Date date) {
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getYear();
	}
	
	public static int extractDateDayAsInt(Date date) {
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getDayOfMonth();
	}
	
	public static String getMonthNamefromInt(int month, Locale locale) {
		if(month < 12 || month > 0) {
			return Month.of(month).getDisplayName(TextStyle.FULL, locale);
		}
		else
			return null;
	}
	
	public static int getMonthfromString(String month) {
		DateTimeFormatter parse = DateTimeFormatter.ofPattern("MMMM").withLocale(Locale.ENGLISH);
		TemporalAccessor access = parse.parse(month);
		return access.get(ChronoField.MONTH_OF_YEAR);
	}
	
	public static String getDayOfWeekfromDate(Date date, Locale locale) {
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		DayOfWeek day = localDate.getDayOfWeek();
		return day.getDisplayName(TextStyle.FULL, locale);
	}
	
	public static int findLengthDaysinMonthYear(int year, int month) {
		YearMonth ym = YearMonth.of(year, month);
		return ym.lengthOfMonth();
	}
	
	public static String calculateDateWithAddtMonthAsString(int intMonth, String StringDatePattern) {
		LocalDate futureDate = LocalDate.now().plusMonths(intMonth);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(StringDatePattern);
		String futureDateString = futureDate.format(dtf);
		
		return futureDateString;
	}
	
	public static String addHourAndMinuteInDateAsString(Date date, int hour, int minute) {
		String afterAddedDateAsString;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR_OF_DAY, hour);
		cal.add(Calendar.MINUTE, minute);

		Date getDateTime;
		getDateTime = cal.getTime();
		afterAddedDateAsString = DateHelper.formatDateToString(getDateTime, "E, dd MMM yyyy - HH:mm");
		return afterAddedDateAsString;
	}
	
	public static String addMinuteInHourAsString(String hourAndMinute, int addWithThisMinute) {
		Calendar cal = Calendar.getInstance();
		DateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH);
		DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		
		try {
			cal.setTime(sdf.parse(hourAndMinute));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cal.add(Calendar.MINUTE, addWithThisMinute);
		String endTime = timeFormat.format(cal.getTime());
		
		return endTime;
	}
	
	public static String addMonthDateAsString(Date date, int month) {
		String afterAdded;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, +month);

		Date getDateTime;
		getDateTime = cal.getTime();
		afterAdded = DateHelper.formatDateToString(getDateTime, "dd MMM yyyy");
		return afterAdded;
	}
	
	public static String minusMonthDateAsString(Date date, int month) {
		String afterAdded;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, - month);

		Date getDateTime;
		getDateTime = cal.getTime();
		afterAdded = DateHelper.formatDateToString(getDateTime, "dd MMM yyyy");
		return afterAdded;
	}
	
	public static Date addDayinDateAsDate(Date date, int day) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, + day);

		Date getDateTime = cal.getTime();
		return getDateTime;
	}
	
	public static LocalDate plusMonths(LocalDate localDate, int Month) {
		if(localDate != null) {
			try {
				return localDate.plusMonths(Month);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			return null;
		}
		return null;
	}
	
	public static String addMonthWithMinusOneDayinDateAsString(Date date, int month) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, +month);
		cal.add(Calendar.DATE, -1);

		Date getDateTime;
		getDateTime = cal.getTime();
		return DateHelper.formatDateToString(getDateTime, "dd MMM yyyy");
	}
	
	public static Date calculateDateWithAddtMonthAsDate(int intMonth) {
		LocalDate futureDate = LocalDate.now().plusMonths(intMonth);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String futureDateString = futureDate.format(dtf);
		Date d = formatStringToDate(futureDateString, "dd mmm yyyy");
		return d;
	}
	
	public static String convertDateNumberToString(String stringDate) {
		Date date = DateHelper.formatStringToDate(stringDate, "yyyy-MM-dd");
		String dateConverted = DateHelper.formatDateToString(date, "dd MMM yyyy");
		return dateConverted;
	}
	
	public static String convertStringToString(String stringDate, String patternFrom, String patternTo) {
		Date date = DateHelper.formatStringToDate(stringDate, patternFrom);
		String dateConverted = DateHelper.formatDateToString(date, patternTo);
		return dateConverted;
	}
	
	public static String convertDateToString(Date date, String patternTo) {
		String dateConverted = DateHelper.formatDateToString(date, patternTo);
		return dateConverted;
	}
	
	public static String convertDateNumberToStringWithStrip(String stringDate) {
		Date date = DateHelper.formatStringToDate(stringDate, "yyyy-MM-dd");
		String dateConverted = DateHelper.formatDateToString(date, "dd-MMM-yyyy");
		return dateConverted;
	}
	
	public static String convertStringDateWithHour(String stringDate) {
		DateFormat readFormat = new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy");
	    DateFormat writeFormat = new SimpleDateFormat("dd MMM yyyy HH:mm");
	    Date date = null;
	    try {
	    	date = readFormat.parse( stringDate );
		}
       	catch (ParseException e) {
			e.printStackTrace();
		}
	    
	    String formattedDate = "";
	    if( date != null ) {
	    	formattedDate = writeFormat.format( date );
	    }
		return formattedDate;
	}
	
	public static String convertStringDateWithMiliSeconds(String stringDate) {
		DateFormat readFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	    DateFormat writeFormat = new SimpleDateFormat("dd MMM yyyy HH:mm");
	    Date date = null;
	    try {
	    	date = readFormat.parse( stringDate );
		}
       	catch (ParseException e) {
			e.printStackTrace();
		}
	    
	    String formattedDate = "";
	    if( date != null ) {
	    	formattedDate = writeFormat.format( date );
	    }
		return formattedDate;
	}
	
	public static LocalDate convertDateToLocalDate(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}
	
	public static Date formatLocalDateToDate(LocalDate localDate) {
		if(localDate != null) {
			Date date = new Date();
			try {
				date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return date;
		} else
			return null;
	}
	
	public static LocalDate formatDateToLocalDate(Date date) {
		if(date != null) {
			LocalDate ld = null;
			try {
				ld = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ld;
		} else
			return null;
	}
	
	public static Date plusDays(Date date, int days) {
		if(date != null) {
			Date d = new Date();
			LocalDate ld = null;
			try {
				ld = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().plusDays(days);
				d = Date.from(ld.atStartOfDay(ZoneId.systemDefault()).toInstant());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return d;
		} else
			return null;
	}
	
	public static int[] generateDates() {
		
		String month = "January";
		int year = 2000;
		
		DateTimeFormatter parser = DateTimeFormatter.ofPattern("MMMM").withLocale(Locale.ENGLISH);
		TemporalAccessor accessor = parser.parse(month); 
		System.out.println(accessor.get(ChronoField.MONTH_OF_YEAR));
		DateHelper.findLengthDaysinMonthYear(year, accessor.get(ChronoField.MONTH_OF_YEAR));
		return IntStream.rangeClosed(1, DateHelper.findLengthDaysinMonthYear(year, accessor.get(ChronoField.MONTH_OF_YEAR))).toArray();
	}
	
	public static List<String> getListOfMonthName(Locale locale) {
		if (locale != null) {
			String[] months = new DateFormatSymbols(locale).getMonths();
			List<String> listMonths = new ArrayList<String>();
			for (int i = 0; i < months.length - 1; i++) {
				listMonths.add(months[i]);
			}
			return listMonths;
		} else
			return null;
	}
	
	public static List<Integer> getListOfYear() {
		LocalDate now = LocalDate.now();
		return IntStream.rangeClosed(1900, now.getYear() + 20).boxed().collect(Collectors.toList());
	}
	
	public static List<Integer> getListOfYearWithRange(int Min, int Max) {
		LocalDate now = LocalDate.now();
		return IntStream.rangeClosed(now.getYear() - Min, now.getYear() + Max).boxed().collect(Collectors.toList());
	}
	
	//Check Date Sanity===========================================================
	public static boolean dateSanity(String date) { 
	 	DateFormat format = new SimpleDateFormat("yyyy-MMMM-dd");
	 	
	 	boolean validDate = true;
	    format.setLenient(false);
	    String dateString = date;
	    
	    try {
	        format.parse(dateString);
	    } catch (ParseException e) {
	        System.out.println("InvalidDate");
	        validDate = false;//Set Flag ValidDate
	        e.printStackTrace();
	    }
	    return validDate;
    }
	//===========================================================
	
}