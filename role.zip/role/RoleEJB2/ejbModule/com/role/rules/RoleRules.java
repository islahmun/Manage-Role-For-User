package com.role.rules;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import come.role.eao.RoleEao;
import entity.Role;

@Stateless
public class RoleRules {

	@EJB
	private RoleEao roleEao;

	public List<Role> getRole(int intCompanyID, String userAccount) {
		try {
			return roleEao.getRole(intCompanyID, userAccount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Role> getRoleMenu(int intCompanyID, int roleID, String User) {
		try {
			return roleEao.getRoleMenu(intCompanyID, roleID, User);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Role> getRoleMenuEdit(int intCompanyID, int roleID, String User) {
		try {
			return roleEao.getRoleMenu(intCompanyID, roleID, User);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Role addRole(Role rl, int compID, String MenuXML, String User) {
		try {
			return roleEao.roleAdd(rl, compID, MenuXML, User);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Role deleteRole(Role del) {
		try {
			return roleEao.roleDelete(del);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Role aktifTidakAktif(Role active) {
		try {
			return roleEao.aktifTidakAktif(active);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Role editRole(Role edit, Role old, String menuXML, String User) {
		try {
			return roleEao.roleEdit(edit, old, menuXML, User);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
