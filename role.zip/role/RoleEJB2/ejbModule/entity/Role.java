package entity;

import java.sql.Timestamp;

public class Role {
	
	private int intRoleID;
	private String roleUID;	
	private int intCompanyID;
	private String roleCode;   
	private String roleName;  
	private int fgRoleStatus;                                      
	private int fgDeleted; 
	private int fgFlowStatus;
	private String fgFlowStatusText;
	private String submitDescription;                                                                                                                                                                                                                                              
	private String rejectDescription;                                                                                                                                                                                                                                                
	private Timestamp  timeLastUpdate;         
	private String userLastUpdate;                                                                                       
	private Timestamp timeBeginJob;            
	private String userBeginJob;                                                                                       
	private Timestamp timeSubmit;              
	private String userSubmit;                                                                                         
	private Timestamp timeLastApprove;         
	private String userLastApprove;                                                                                    
	private int resultSuccess;
	private int errorMessage;
	private String menuXML;
	private String deleteReason;
	private String userAccount;
	private String outRoleUID;
	private int intMenuID;
	private String menuName;
	private String fgMenuType;
	private int intParentMenuID;
	private int fgAllow;
	private int fgFlowStatusDetail; 

	
	public String getRoleUID() {
		return roleUID;
	}
	public int getIntRoleID() {
		return intRoleID;
	}
	public void setIntRoleID(int intRoleID) {
		this.intRoleID = intRoleID;
	}
	public String getFgFlowStatusText() {
		return fgFlowStatusText;
	}
	public void setFgFlowStatusText(String fgFlowStatusText) {
		this.fgFlowStatusText = fgFlowStatusText;
	}
	public void setRoleUID(String roleUID) {
		this.roleUID = roleUID;
	}
	
	public int getIntCompanyID() {
		return intCompanyID;
	}
	public void setIntCompanyID(int intCompanyID) {
		this.intCompanyID = intCompanyID;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	public int getFgRoleStatus() {
		return fgRoleStatus;
	}
	public void setFgRoleStatus(int fgRoleStatus) {
		this.fgRoleStatus = fgRoleStatus;
	}
	public int getFgDeleted() {
		return fgDeleted;
	}
	public void setFgDeleted(int fgDeleted) {
		this.fgDeleted = fgDeleted;
	}
	
	public int getFgFlowStatus() {
		return fgFlowStatus;
	}
	public void setFgFlowStatus(int fgFlowStatus) {
		this.fgFlowStatus = fgFlowStatus;
	}
	
	public String getSubmitDescription() {
		return submitDescription;
	}
	public void setSubmitDescription(String submitDescription) {
		this.submitDescription = submitDescription;
	}
	public String getRejectDescription() {
		return rejectDescription;
	}
	public void setRejectDescription(String rejectDescription) {
		this.rejectDescription = rejectDescription;
	}
		
	public String getUserLastUpdate() {
		return userLastUpdate;
	}
	public void setUserLastUpdate(String userLastUpdate) {
		this.userLastUpdate = userLastUpdate;
	}
	
	public String getUserBeginJob() {
		return userBeginJob;
	}
	public void setUserBeginJob(String userBeginJob) {
		this.userBeginJob = userBeginJob;
	}
	
	public String getUserSubmit() {
		return userSubmit;
	}
	public void setUserSubmit(String userSubmit) {
		this.userSubmit = userSubmit;
	}
	
	public String getUserLastApprove() {
		return userLastApprove;
	}
	public void setUserLastApprove(String userLastApprove) {
		this.userLastApprove = userLastApprove;
	}
	public Timestamp getTimeLastUpdate() {
		return timeLastUpdate;
	}
	public void setTimeLastUpdate(Timestamp timeLastUpdate) {
		this.timeLastUpdate = timeLastUpdate;
	}
	public Timestamp getTimeBeginJob() {
		return timeBeginJob;
	}
	public void setTimeBeginJob(Timestamp timeBeginJob) {
		this.timeBeginJob = timeBeginJob;
	}
	public Timestamp getTimeSubmit() {
		return timeSubmit;
	}
	public void setTimeSubmit(Timestamp timeSubmit) {
		this.timeSubmit = timeSubmit;
	}
	public Timestamp getTimeLastApprove() {
		return timeLastApprove;
	}
	public void setTimeLastApprove(Timestamp timeLastApprove) {
		this.timeLastApprove = timeLastApprove;
	}
	public int getResultSuccess() {
		return resultSuccess;
	}
	public void setResultSuccess(int resultSuccess) {
		this.resultSuccess = resultSuccess;
	}
	public int getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(int errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getMenuXML() {
		return menuXML;
	}
	public void setMenuXML(String menuXML) {
		this.menuXML = menuXML;
	}
	public String getDeleteReason() {
		return deleteReason;
	}
	public void setDeleteReason(String deleteReason) {
		this.deleteReason = deleteReason;
	}
	public String getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}
	public String getOutRoleUID() {
		return outRoleUID;
	}
	public void setOutRoleUID(String outRoleUID) {
		this.outRoleUID = outRoleUID;
	}
	
	public int getIntMenuID() {
		return intMenuID;
	}
	public void setIntMenuID(int intMenuID) {
		this.intMenuID = intMenuID;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	
	public String getFgMenuType() {
		return fgMenuType;
	}
	public void setFgMenuType(String fgMenuType) {
		this.fgMenuType = fgMenuType;
	}
	public int getIntParentMenuID() {
		return intParentMenuID;
	}
	public void setIntParentMenuID(int intParentMenuID) {
		this.intParentMenuID = intParentMenuID;
	}
	public int getFgAllow() {
		return fgAllow;
	}
	public void setFgAllow(int fgAllow) {
		this.fgAllow = fgAllow;
	}
	public int getFgFlowStatusDetail() {
		return fgFlowStatusDetail;
	}
	public void setFgFlowStatusDetail(int fgFlowStatusDetail) {
		this.fgFlowStatusDetail = fgFlowStatusDetail;
	}
	
}
