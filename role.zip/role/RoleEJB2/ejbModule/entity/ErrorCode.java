package entity;

public class ErrorCode {
	
	private int errorCode;
	private String errorMessageID;
	
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessageID() {
		return errorMessageID;
	}
	public void setErrorMessageID(String errorMessageID) {
		this.errorMessageID = errorMessageID;
	}
}